﻿setInterval(() => {
    window.location.reload()
}, 900000)